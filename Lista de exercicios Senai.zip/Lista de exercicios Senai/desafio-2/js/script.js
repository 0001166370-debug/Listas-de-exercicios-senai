function externalfunction(){
            document.getElementById("EXT").innerHTML = "demo JS external alterado";
        }
        document
        .getElementById("buttext")
        .addEventListener("click",externalfunction);
        