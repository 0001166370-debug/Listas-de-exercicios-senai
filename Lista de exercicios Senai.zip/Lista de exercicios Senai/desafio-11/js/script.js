// Desafio 11: JS Arithmetic
const x = 10;
let y = 3;
console.log('Quadrado de x =', x * x);
console.log('x / y (2 casas) =', (x / y).toFixed(2));
y++;
console.log('y após incremento =', y);
