// Desafio 17: Entrada de Dados
const nome = prompt('Digite seu nome:');
if (nome) {
  alert('Olá, ' + nome + '!');
  console.log('Nome informado:', nome);
} else {
  alert('Olá!');
}
