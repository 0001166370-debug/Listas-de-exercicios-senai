(nome = "Maria");
console.log("Bem-vinda " + nome);
