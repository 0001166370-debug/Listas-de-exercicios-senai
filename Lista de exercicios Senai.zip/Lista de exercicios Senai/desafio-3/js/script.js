alert('Esta e uma mensagem exibida com alert().');
console.log('Esta e uma mensagem exibida com console.log().');
document.write('<p>Esta e uma mensagem exibida com document.write().</p>');
