// Desafio 20: Miniprojeto
const form = document.getElementById('form');
const saida = document.getElementById('saida');
form.addEventListener('submit', function(e) {
  e.preventDefault();
  const nome = document.getElementById('nome').value;
  const idade = document.getElementById('idade').value;
  saida.textContent = `Olá ${nome}, você tem ${idade} anos.`;
});
