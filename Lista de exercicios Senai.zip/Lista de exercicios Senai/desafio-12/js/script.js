// Desafio 12: JS Assignment
let pontos = 5;
console.log('Inicial:', pontos);
pontos += 3;
console.log('+= 3 ->', pontos);
pontos -= 2;
console.log('-= 2 ->', pontos);
pontos *= 4;
console.log('*= 4 ->', pontos);
pontos %= 3;
console.log('%= 3 ->', pontos);
