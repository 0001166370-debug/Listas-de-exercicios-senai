// Desafio 18: Condicional Simples
const idadeStr = prompt('Informe sua idade:');
const idade = parseInt(idadeStr, 10);
if (isNaN(idade)) {
  alert('Idade inválida');
} else {
  if (idade >= 18) alert('Você é maior de idade');
  else alert('Você é menor de idade');
}
