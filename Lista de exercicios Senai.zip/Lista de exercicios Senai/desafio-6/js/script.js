// descreve a declaração de variável abaixo 
var nome = "Maria";

/*
   o código abaixo
  exibe uma mensagem de boas-vindas usando console.log().
*/
console.log("Bem-vinda " + nome);
