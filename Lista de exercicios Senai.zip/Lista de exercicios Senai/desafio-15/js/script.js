// Desafio 15: Concatenação
const nome = 'Caetano';
const sobrenome = 'Silva';
const nomeCompleto = nome + ' ' + sobrenome;
console.log('Nome completo:', nomeCompleto);
