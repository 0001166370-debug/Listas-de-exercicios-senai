// Desafio 7: JS Variables
var nome = 'SeuNome';
var idade = 25;
var estudando = true;
console.log('Nome:', nome);
console.log('Idade:', idade);
console.log('Estudando?', estudando);
