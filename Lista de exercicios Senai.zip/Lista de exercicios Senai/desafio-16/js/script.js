// Desafio 16: Template Strings
const nome = 'Caetano';
const sobrenome = 'Silva';
const mensagem = `Meu nome é ${nome} ${sobrenome}`;
console.log(mensagem);
