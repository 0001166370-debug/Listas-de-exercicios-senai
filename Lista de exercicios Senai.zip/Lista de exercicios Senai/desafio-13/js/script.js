// Desafio 13: JS Data Types
const texto = 'Olá';
const numero = 42;
const booleano = false;
const lista = [1, 2, 3];
const obj = {chave: 'valor'};
console.log(typeof texto, texto);
console.log(typeof numero, numero);
console.log(typeof booleano, booleano);
console.log(typeof lista, lista);
console.log(typeof obj, obj);
