(nome = 'Joao');
(idade = 20);
(soma = 5 + 10);
console.log('Nome:', nome);
console.log('Idade:', idade);
console.log('Soma de 5 + 10 =', soma);
console.log('Mensagem:', nome + ' tem ' + idade + ' anos.');
console.log('A soma da idade mais o numero e igual a:',idade+soma);
