// Desafio 8: JS Let
let pontuacao = 0;
console.log('Pontuação inicial:', pontuacao);
pontuacao = 10;
console.log('Após primeira atualização:', pontuacao);
pontuacao += 5;
console.log('Após segunda atualização:', pontuacao);
