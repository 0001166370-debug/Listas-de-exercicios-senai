// Desafio 14: Mistura de Tipos
const aluno = {
  nome: 'Ana',
  idade: 21,
  curso: 'Web',
  notas: [8, 7.5, 9]
};
const soma = aluno.notas.reduce((a,b) => a + b, 0);
const media = soma / aluno.notas.length;
console.log('Aluno:', aluno.nome);
console.log('Média das notas =', media);
