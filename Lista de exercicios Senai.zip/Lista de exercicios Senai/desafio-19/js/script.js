// Desafio 19: Condicional Composta
const n1 = parseFloat(prompt('Primeira nota:')) || 0;
const n2 = parseFloat(prompt('Segunda nota:')) || 0;
const media = (n1 + n2) / 2;
if (media >= 7) alert('Aprovado! Média: ' + media.toFixed(2));
else alert('Reprovado. Média: ' + media.toFixed(2));
console.log('Média calculada =', media);
