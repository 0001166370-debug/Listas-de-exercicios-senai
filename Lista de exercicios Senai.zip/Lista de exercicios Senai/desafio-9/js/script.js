// Desafio 9: JS Const
const PI = 3.14;
console.log('PI inicial:', PI);
try {
  PI = 3.1415; // tentativa de alterar
} catch (e) {
  console.log('Erro ao tentar alterar PI:', e.message);
}
console.log('PI permanece:', PI);
